package PageObjects;

public class Home {

}
